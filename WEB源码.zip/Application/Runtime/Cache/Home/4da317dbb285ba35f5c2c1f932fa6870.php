<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
	    <div class="layui-btn-group">
            <button class="layui-btn data-add-btn">添加新的广告流</button>
        </div>
		<table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>
<script class="EditAdsInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="AdsInfo">
		                 <div class="layui-hide">
                              <label class="layui-form-label">ID</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="id" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item">
                              <label class="layui-form-label">广告名</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="ads_name" lay-verify="required" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">广告标题</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="ads_title" lay-verify="required" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">跳转地址</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="ads_url" lay-verify="required|url" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						  <div class="layui-form-item">
                              <label class="layui-form-label">图片地址</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="ads_img" lay-verify="required|url" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">到期时间</label>
                              <div class="layui-input-inline">
                                   <input onfocus="this.blur();" id="ads_time" type="text" name="ads_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="submit"></button>
                         </div>
				   </form>
</script>
<script class="AddAdsInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="AdsInfo">
		                 <div class="layui-form-item">
                              <label class="layui-form-label">广告名</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="ads_name" lay-verify="required" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">广告标题</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="ads_title" lay-verify="required" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">跳转地址</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="ads_url" lay-verify="required|url" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">图片地址</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="ads_img" lay-verify="required|url" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">到期时间</label>
                              <div class="layui-input-inline">
                                   <input onfocus="this.blur();" id="ads_time" type="text" name="ads_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="add_ads"></button>
                         </div>
		 </form>
</script>
<script src="/static/lib/laydate/laydate.js"></script>
<script>
    layui.use(['form', 'table'], function () {
	    var laydate = layui.laydate;
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
		form.render();
        table.render({
            elem: '#currentTableId',
            url: './Home/Ads/AdsList',
			height: 500,
			loading: true,
			method: 'post',
			limits: [10],
            limit: 10,
			cellMinWidth: 80,
            page: true,
            cols: [[
                {field: 'id',width: 60, title: 'ID', sort: true},
                {field: 'ads_name', title: '广告名'},
				{field: 'ads_title', title: '广告标题'},
				{field: 'ads_time', title: '到期时间'},
				{field: 'ads_url', title: '跳转地址'},
				{field: 'ads_img', title: '图片地址'},
                {title: '操作', minWidth: 120, templet: '#currentTableBar', fixed: "right", align: "center"}
            ]]
        });
		$(".data-add-btn").on("click", function () {
            layer.open({
                     content: $('.AddAdsInfo').html()
					 ,title: '添加新的广告流'
                     ,btn: ['提交', '取消']
					 ,success: function(layero, index){
					       laydate.render({
                                   elem: '#ads_time'
                                   ,type: 'datetime'
                               });
						   form.render('radio');
						   laydate.render({
                                   elem: '#create_time'
                                   ,type: 'datetime'
                            });
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
        });
		form.on('submit(add_ads)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Ads/AddAds",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
		form.on('submit(submit)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Ads/EditAds",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
				layer.open({
                     content: $('.EditAdsInfo').html()
					 ,title: '编辑 '+data.ads_name
                     ,btn: ['提交修改', '取消']
					 ,success: function(layero, index){
					           laydate.render({
                                   elem: '#create_time'
                                   ,type: 'datetime'
                               });
							   laydate.render({
                                   elem: '#ads_time'
                                   ,type: 'datetime'
                               });
							   form.render('radio');
							   form.val('AdsInfo', {
                                        "id": data.id,
										"ads_name": data.ads_name,
										"ads_title": data.ads_title,
										"ads_url": data.ads_url,
										"ads_time": data.ads_time,
										"ads_img": data.ads_img
										
                                        										
                               })
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除 '+data.ads_name, function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Ads/AdsDel",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
                        if(result.status==0){
                           layer.msg(result.msg);
                          }
                        else
                          layer.msg(result.msg);
						layer.close(loading);
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });
    });
</script>