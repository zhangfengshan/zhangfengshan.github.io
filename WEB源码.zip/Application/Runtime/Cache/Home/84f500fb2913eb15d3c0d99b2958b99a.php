<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
        <fieldset class="layui-elem-field layuimini-search">
            <legend>检索信息</legend>
            <div style="margin: 10px 10px 10px 10px">
                <form class="layui-form layui-form-pane" action="">
				    <div class="layui-form-item">
			            <div class="layui-inline">
                        <label class="layui-form-label">软件选择</label>
                        <div class="layui-input-inline">
                            <select lay-verify="required" lay-filter="soft"  lay-reqtext="软件都不选择，你看谁的码？">
						            <option value="">请选择软件</option>
						            <?php if(is_array($softlist)): $i = 0; $__LIST__ = $softlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </div>
                        </div>
			        </div>
                    <div class="layui-form-item">
                        <div class="layui-inline">
                            <label class="layui-form-label">注册码</label>
                            <div class="layui-input-inline">
                                <input type="text" name="card" lay-verify="required" autocomplete="off" class="layui-input">
                            </div>
                        </div>
                        <div class="layui-inline">
                            <a class="layui-btn" lay-submit="" lay-filter="data-search-btn">搜索</a>
                        </div>
                    </div>
                </form>
            </div>
        </fieldset>
		<div class="layui-btn-group">
            <button class="layui-btn data-export">导出</button>
        </div>
        <table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
		<script type="text/html" id="switchTpl">
        </script>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>
<script class="EditCodeInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="CodeInfo">
		                 <div class="layui-form-item">
                              <label class="layui-form-label">注册码</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="code" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
				         <div class="layui-form-item">
                              <label class="layui-form-label">生成时间</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled" type="text" name="produce_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">时长</label>
                              <div class="layui-input-inline">
                                   <input type="text" disabled="disabled" name="time_str" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">机器码</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="computer_uid" autocomplete="off" class="layui-input">
								   <tip>如果为空/表示解绑</tip>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">到期时间</label>
                              <div class="layui-input-inline">
                                   <input onfocus="this.blur();" id="expire_time" type="text" name="expire_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						  <div class="layui-form-item">
                              <label class="layui-form-label">使用时间</label>
                              <div class="layui-input-inline">
                                   <input type="text" disabled="disabled" name="beginuse_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">上次授权</label>
                              <div class="layui-input-inline">
                                   <input type="text" disabled="disabled" name="last_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">授权IP</label>
                              <div class="layui-input-inline">
                                   <input type="text" disabled="disabled" name="last_ip" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">授权次数</label>
                              <div class="layui-input-inline">
                                   <input type="text" disabled="disabled" name="use_count" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">备注</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="mark" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">状态</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="frozen" value="0" title="正常" checked="">
                                   <input type="radio" name="frozen" value="1" title="冻结">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="submit"></button>
                         </div>
		 </form>
</script>
<script src="/static/lib/laydate/laydate.js"></script>
<script>
    layui.use(['form', 'table'], function () {
	    var laydate = layui.laydate;
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
	    form.render();
		var ins1 = table.render({
            elem: '#currentTableId',
            url: './Home/Managecode/CodeList',
			height: 500,
			loading: true,
			title: '注册码',
			method: 'post',
			limits: [10],
            limit: 10,
            page: true,
			cellMinWidth: 80,
            cols: [[
                {field: 'id', width: 60,  title: 'ID', sort: true},
                {field: 'code', title: '注册码'},
                {field: 'time_str',  title: '时长'},
                {field: 'produce_time',  title: '创建时间'},
                {field: 'frozen',  title: '状态' ,templet:function(rec){
							if(rec.frozen=='0'){
	        					return "正常";
	        				}else if(rec.frozen=='1'){
	        					return "冻结";
	        				}else{
	        					return rec.frozen;
	        				}
        		}},
                {title: '操作', minWidth: 120,  templet: '#currentTableBar', fixed: "right", align: "center"}
            ]],
			done: function (res, curr, count) {
                exportData=res.data;
            }
        });
	    form.on('select(soft)', function(data){
		              var ins1 = table.render({
                      elem: '#currentTableId',
                      url: './Home/Managecode/CodeList',
			          height: 500,
					  loading: true,
					  title: '注册码',
			          method: 'post',
			          limits: [10],
                      limit: 10,
		              where: {softid: data.value},
						page: true,
						cellMinWidth: 80,
						cols: [[
						{field: 'id', width: 60,  title: 'ID', sort: true},
						{field: 'code', title: '注册码'},
						{field: 'time_str',  title: '时长'},
						{field: 'produce_time',  title: '创建时间'},
						{field: 'frozen',  title: '状态' ,templet:function(rec){
									if(rec.frozen=='0'){
										return "正常";
									}else if(rec.frozen=='1'){
										return "冻结";
									}else{
										return rec.frozen;
									}
						}},
						{title: '操作', minWidth: 120,  templet: '#currentTableBar', fixed: "right", align: "center"}
						]],
						done: function (res, curr, count) {
                              exportData=res.data;
                        }
              });
	    })
		$(".data-export").on("click", function () {
            table.exportFile(ins1.config.id,exportData, 'csv');
        });
        form.on('submit(data-search-btn)', function (data) {
            var result = JSON.stringify(data.field);
            table.reload('currentTableId', {
                page: {
                    curr: 1
                }
                , where: {
                    searchParams: result
                }
            }, 'data');

            return false;
        });
		form.on('submit(submit)', function (data) {
		    var loading = layer.load(0, {
                    shade: false
                });
			$.ajax({
                      url:"./Home/Managecode/EditCode",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
						layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
                layer.open({
                     content: $('.EditCodeInfo').html()
					 ,title: '编辑 '+data.code
                     ,btn: ['提交修改', '取消']
					 ,success: function(layero, index){
					           laydate.render({
                                   elem: '#expire_time'
                                   ,type: 'datetime'
                               });
                               form.render('radio');
							   form.val('CodeInfo', {
                                        "code": data.code,
										"time_str": data.time_str,
										"produce_time": data.produce_time,
										"beginuse_time": data.beginuse_time,
										"computer_uid": data.computer_uid,
										"expire_time": data.expire_time,
										"last_ip": data.last_ip,
										"use_count": data.use_count,
										"frozen": data.frozen,
										"mark": data.mark,
										"last_time": data.last_time
                                        										
                               })
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除 '+data.code+' 卡密', function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Managecode/CodeDel",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
                        if(result.status==0){
                           layer.msg(result.msg);
                          }
                        else
                          layer.msg(result.msg);
						layer.close(loading);
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });

    });
</script>