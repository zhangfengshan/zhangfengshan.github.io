<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
	    <div class="layui-btn-group">
            <button class="layui-btn data-add-btn">添加新的代理</button>
        </div>
		<table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>
<script class="EditProxyInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="ProxyInfo">
		                 <div class="layui-hide">
                              <label class="layui-form-label">ID</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="id" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item">
			                 <div class="layui-inline">
                             <label class="layui-form-label">软件选择</label>
                             <div class="layui-input-inline">
                                  <select lay-verify="required" name="soft" lay-reqtext="软件都不选择，你想干嘛？" xm-select="selectId" xm-select-skin="danger">
						                    <option value="">请选择软件</option>
						                    <?php if(is_array($softlist)): $i = 0; $__LIST__ = $softlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                  </select>
                             </div>
                             </div>
			             </div>
		                 <div class="layui-form-item">
                              <label class="layui-form-label">账号</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required" name="username" autocomplete="off"  class="layui-input">
                              </div>
                         </div> 
						 <div class="layui-form-item">
                              <label class="layui-form-label">密码</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required" name="password" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">余额</label>
                              <div class="layui-input-inline">
                                   <input type="number" lay-verify="required|number" name="money" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">开卡费率</label>
                              <div class="layui-input-inline">
                                   <input type="number" lay-verify="required|number" name="rate" placeholder="(0.00-1.00)" autocomplete="off"  class="layui-input">
                              </div>
							  <tip>月卡10/赚的比例(0.5*10)=5(你所赚的)+10 下级开15</tip>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">代理权限</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="is_addproxy" value="0" title="关闭" checked="">
                                   <input type="radio" name="is_addproxy" value="1" title="开启">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">状态</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="frozen" value="0" title="正常" checked="">
                                   <input type="radio" name="frozen" value="1" title="冻结">
                              </div>
                         </div> 
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="edit_proxy"></button>
                         </div>
				   </form>
</script>
<script class="AddProxyInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="ProxyInfo">
		                <div class="layui-form-item">
			                 <div class="layui-inline">
                             <label class="layui-form-label">软件选择</label>
                             <div class="layui-input-inline">
                                  <select lay-verify="required" name="soft" lay-reqtext="软件都不选择，你想干嘛？" xm-select="selectId" xm-select-skin="danger">
						                    <option value="">请选择软件</option>
						                    <?php if(is_array($softlist)): $i = 0; $__LIST__ = $softlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                  </select>
                             </div>
                             </div>
			             </div>
		                 <div class="layui-form-item">
                              <label class="layui-form-label">账号</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required" name="username" autocomplete="off"  class="layui-input">
                              </div>
                         </div> 
						 <div class="layui-form-item">
                              <label class="layui-form-label">密码</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required" name="password" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">余额</label>
                              <div class="layui-input-inline">
                                   <input type="number" lay-verify="required|number" name="money" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">开卡费率</label>
                              <div class="layui-input-inline">
                                   <input type="number" lay-verify="required|number" name="rate" placeholder="(0.00-1.00)" autocomplete="off"  class="layui-input">
                              </div>
							  <tip>月卡10/赚的比例(0.5*10)=5(你所赚的)+10 下级开15</tip>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">代理权限</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="is_addproxy" value="0" title="关闭" checked="">
                                   <input type="radio" name="is_addproxy" value="1" title="开启">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">状态</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="frozen" value="0" title="正常" checked="">
                                   <input type="radio" name="frozen" value="1" title="冻结">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="add_proxy"></button>
                         </div>
				   </form>
</script>

<script>
    layui.config({
        base: '/static/js/'
    }).extend({
        formSelects: 'formSelects-v4'
    });
    layui.use(['form', 'table', 'formSelects'], function () {
	    var formSelects = layui.formSelects;
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
		
		form.render();
        table.render({
            elem: '#currentTableId',
            url: './Home/Proxy/ProxyList',
			height: 500,
			loading: true,
			method: 'post',
			limits: [10],
            limit: 10,
			cellMinWidth: 80,
            page: true,
            cols: [[
                {field: 'id',width: 60, title: 'ID', sort: true},
                {field: 'username', title: '代理账号'},
				{field: 'password', title: '代理密码'},
				{field: 'money', title: '代理余额'},
				{field: 'rate', title: '开卡费率'},
				{field: 'is_addproxy', title: '代理权限',templet:function(rec){
							if(rec.is_addproxy=='0'){
	        					return "关闭";
	        				}else if(rec.is_addproxy=='1'){
	        					return "开启";
	        				}else{
	        					return rec.is_addproxy;
	        				}
        		}},
				{field: 'frozen', title: '代理状态',templet:function(rec){
							if(rec.frozen=='0'){
	        					return "正常";
	        				}else if(rec.frozen=='1'){
	        					return "冻结";
	        				}else{
	        					return rec.frozen;
	        				}
        		}},
                {title: '操作', minWidth: 120, templet: '#currentTableBar', fixed: "right", align: "center"}
            ]]
        });
		$(".data-add-btn").on("click", function () {
            layer.open({
                     content: $('.AddProxyInfo').html()
					 ,title: '添加新的代理'
                     ,btn: ['提交', '取消']
					 ,success: function(layero, index){
					       form.render();
						   formSelects.render('selectId');
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
        });
		form.on('submit(add_proxy)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Proxy/AddProxy",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
		form.on('submit(edit_proxy)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Proxy/EditProxy",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
				layer.open({
                     content: $('.EditProxyInfo').html()
					 ,title: '编辑 '+data.username
                     ,btn: ['提交修改', '取消']
					 ,success: function(layero, index){
					           form.render();
						       formSelects.render('selectId');
							   formSelects.value('selectId',data.soft.split(',')); 
							   form.val('ProxyInfo', {
                                        "id": data.id,
										"username": data.username,
										"password": data.password,
										"money": data.money,
										"rate": data.rate,
										"frozen": data.frozen,
										"soft": data.soft,
										"is_addproxy": data.is_addproxy
                                        										
                               });
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除 '+data.username, function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Proxy/ProxyDel",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
                        if(result.status==0){
                           layer.msg(result.msg);
                          }
                        else
                          layer.msg(result.msg);
						layer.close(loading);
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });

    });
</script>