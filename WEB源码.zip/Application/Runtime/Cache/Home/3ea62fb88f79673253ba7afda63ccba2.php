<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
	    <fieldset class="layui-elem-field layuimini-search">
            <legend>搜索信息</legend>
            <div style="margin: 10px 10px 10px 10px">
                <form class="layui-form layui-form-pane" action="">
                    <div class="layui-form-item">
                        <div class="layui-inline">
                            <label class="layui-form-label">应用名</label>
                            <div class="layui-input-inline">
                                <input type="text" name="name" lay-verify="required" autocomplete="off" class="layui-input">
                            </div>
                        </div>
                        <div class="layui-inline">
                            <a class="layui-btn" lay-submit="" lay-filter="data-search-btn">搜索</a>
                        </div>
                    </div>
                </form>
            </div>
        </fieldset>
		<table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>

<!--云网络验证-->
<script class="AuthEditSoftInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="SoftInfo">
		                 <div class="layui-hide">
                              <label class="layui-form-label">模式</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="authmode" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item">
                              <label class="layui-form-label">APPID</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="id" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
				         <div class="layui-form-item">
                              <label class="layui-form-label">软件名</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="name" lay-verify="required" lay-reqtext="软件名是必填项，岂能为空？" autocomplete="off" placeholder="请输入软件名" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">试用分钟</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required" name="try_minutes" autocomplete="off" placeholder="填0代表不可试用" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">试用次数</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required" name="try_count" autocomplete="off" placeholder="填0代表不可试用" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">绑机模式</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="bindmode" value="0" title="绑机单开" checked="">
                                   <input type="radio" name="bindmode" value="1" title="绑机多开">
                                   <input type="radio" name="bindmode" value="2" title="不绑机多开">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">弹窗标题</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required" lay-reqtext="标题是必填项，岂能为空？" name="title" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">公告</label>
                              <div class="layui-input-block">
                                   <textarea lay-verify="required" placeholder="请输入内容" class="layui-textarea" name="notice"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">发卡网地址</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="url" name="weburl" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">软件版本</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="version" autocomplete="off" class="layui-input" placeholder="请输入非负整数" value="1">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">更新地址</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="url" name="update_url" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">更新内容</label>
                              <div class="layui-input-block">
                                   <textarea placeholder="请输入内容" class="layui-textarea" name="update_msg"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">更新模式</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="updatemode" value="0" title="强制" checked="">
                                   <input type="radio" name="updatemode" value="1" title="可选">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">运营状态</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="frozen" value="0" title="运营" checked="">
                                   <input type="radio" name="frozen" value="1" title="停用">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="submit"></button>
                         </div>
				   </form>
</script>
<!--引流加群-->
<script class="GroupEditSoftInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="SoftInfo">
		                 <div class="layui-hide">
                              <label class="layui-form-label">模式</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="authmode" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item">
                              <label class="layui-form-label">APPID</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="id" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
				         <div class="layui-form-item">
                              <label class="layui-form-label">软件名</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="name" lay-verify="required" lay-reqtext="软件名是必填项，岂能为空？" autocomplete="off" placeholder="请输入软件名" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">弹窗标题</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required" lay-reqtext="标题是必填项，岂能为空？" name="title" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">提示信息</label>
                              <div class="layui-input-block">
                                   <textarea lay-verify="required" placeholder="请输入内容" class="layui-textarea" name="notice"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">分享次数</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="share_count" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">分享内容</label>
                              <div class="layui-input-block">
                                   <textarea lay-verify="required" placeholder="请输入内容" class="layui-textarea" name="share_msg"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">多久显示</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="delay_time" autocomplete="off" placeholder="单位/秒 填0代表立即显示" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">显示次数</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="show_count" autocomplete="off" placeholder="填0代表不显示" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">更多资源</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|url" name="more_url" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">客服QQ</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="qq_key" autocomplete="off"class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">群号</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="group_key" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">运营状态</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="frozen" value="0" title="运营" checked="">
                                   <input type="radio" name="frozen" value="1" title="停用">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="submit"></button>
                         </div>
		 </form>
</script>
<script>
    layui.use(['form', 'table'], function () {
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
		form.render();
        table.render({
            elem: '#currentTableId',
            url: './Home/Managesoft/SoftList',
			height: 500,
			loading: true,
			method: 'post',
			limits: [10],
            limit: 10,
			cellMinWidth: 80,
            page: true,
            cols: [[
                {field: 'id',  title: 'APPID', sort: true},
                {field: 'name', title: '软件名'},
                // {field: 'authmode', title: '模式', templet:function(rec){
					// 		if(rec.authmode=='0'){
	        	// 				return "云网络验证";
	        	// 			}else if(rec.authmode=='1'){
	        	// 				return "引流加群";
	        	// 			}else{
	        	// 				return rec.authmode;
	        	// 			}
        		// }},
                {field: 'frozen',  title: '状态', templet:function(rec){
							if(rec.frozen=='0'){
	        					return "运营";
	        				}else if(rec.frozen=='1'){
	        					return "停用";
	        				}else{
	        					return rec.frozen;
	        				}
        		}},
                {title: '操作', minWidth: 120, templet: '#currentTableBar', fixed: "right", align: "center"}
            ]]
        });
        form.on('submit(data-search-btn)', function (data) {
            var result = JSON.stringify(data.field);
            table.reload('currentTableId', {
                page: {
                    curr: 1
                }
                , where: {
                    searchParams: result
                }
            }, 'data');

            return false;
        });
		form.on('submit(submit)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Managesoft/EditSoft",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
			    var html;
				switch(data.authmode)
				{
				  case "0":
				     html=$('.AuthEditSoftInfo').html();
				  break;
				  case "1":
				     html=$('.GroupEditSoftInfo').html();
				  break;
				}
				layer.open({
                     type: 2
                     ,area : ['320px','500px']
                     ,content: "/home/changesoft?sid="+data.id
					 ,title: '编辑 '+data.name

               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除 '+data.name+' 应用', function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Managesoft/DeleteSoft",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
                        if(result.status==0){
                           layer.msg(result.msg);
                          }
                        else
                          layer.msg(result.msg);
						layer.close(loading);
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });

    });
</script>