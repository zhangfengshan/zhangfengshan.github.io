<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
        <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
            <legend>注册码生成系统</legend>
        </fieldset>
        <form class="layui-form layui-form-pane" action="" lay-filter="card">
		    <div class="layui-form-item">
			   <div class="layui-inline">
                    <label class="layui-form-label">软件选择</label>
                    <div class="layui-input-inline">
                        <select name="soft" lay-verify="required" lay-reqtext="软件都不选择，你给谁生成码？">
						    <option value="">请选择软件</option>
						    <?php if(is_array($softlist)): $i = 0; $__LIST__ = $softlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </div>
                </div>
			</div>
		    <div class="layui-form-item">
                <label class="layui-form-label">生成张数</label>
                <div class="layui-input-inline">
                    <input type="text" name="count" lay-verify="required|number" lay-reqtext="数量是必填项，岂能为空？" placeholder="请输入" autocomplete="off" class="layui-input" value="1">
                </div>
            </div>
			<div class="layui-form-item">
                <label class="layui-form-label">注册码时长</label>
                <div class="layui-input-inline">
                    <input type="text" name="time" lay-verify="required|number" lay-reqtext="时长是必填项，岂能为空？" placeholder="请输入" autocomplete="off" class="layui-input" value="1">
                </div>
            </div>
			<div class="layui-form-item">
			   <div class="layui-inline">
                    <label class="layui-form-label">注册码类型</label>
                    <div class="layui-input-inline">
                        <select name="modules" lay-verify="required">
                            <option value="">请选择注册码类型</option>
                            <option value="1">小时卡</option>
                            <option value="2">天卡</option>
                            <option value="3">月卡</option>
                            <option value="4">季卡</option>
                            <option value="5">年卡</option>
                        </select>
                    </div>
                </div>
			</div>
			<div class="layui-form-item">
                <label class="layui-form-label">备注</label>
                <div class="layui-input-inline">
                    <input type="text" name="mark" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">生成结果</label>
                <textarea rows="20" cols="20" name="list" class="layui-textarea"></textarea>
            </div>
            <div class="layui-form-item">
                <button class="layui-btn" lay-submit="" lay-filter="create" >立即生成</button>
                <button type="reset" class="layui-btn layui-btn-primary">重置</button>
            </div>
        </form>
    </div>
</div>
<script>
    layui.use(['form', 'layedit', 'laydate'], function () {
	    var $ = layui.jquery;
        var form = layui.form
            , layer = layui.layer
            , layedit = layui.layedit
            , laydate = layui.laydate;
        form.render();
		form.on('submit(create)', function (data) {
		    var loading = layer.load(0, {
                    shade: false
                });
            $.ajax({
                url:"./Home/Createcode/Code",
                method:'post',
                data:data.field,
				xhrFields: {
                  withCredentials: true
                },
                crossDomain: true,
                dataType:'JSON',
                success:function(res){
				    var result = JSON.parse(res);
                    if(result.status==0){
					    form.val('card', {
                          "list": result.msg.replace(/[|]/g,'\n')
                        })
                    }
                    else
                        layer.msg(result.msg);
						
					layer.close(loading);
                },
                error:function (e) {
                    layer.msg("提交错误");
					layer.close(loading);
                }
            })
           return false;
        });
    });
</script>