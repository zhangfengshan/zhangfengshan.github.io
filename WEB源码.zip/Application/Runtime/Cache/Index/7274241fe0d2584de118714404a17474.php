<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zxx">
<head>
    <title><?php echo ($name); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="" />
    <script>
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <link href="/static/css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="/static/css/style.css" type="text/css" rel="stylesheet" media="all">
    <link href="/static/css/font-awesome.min.css" rel="stylesheet">
     <link rel="shortcut icon" href="http://tlx.z74d.cn/static/image/logo.png">
    <link href="http://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800" rel="stylesheet">
</head>

<body>
    <section class="main-banner" id="home">
        
        <div class="container">
            <div class="baner-info-w3ls text-left">
                <h1><?php echo ($name); ?></h1>
                <h6 class="mx-auto mt-4">软件授权管理一站式解决方案，业务上云，拥抱云时代</h6>
                	<br>
                <a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="/Home/Login"  role="button">商户登录</a> 
                <a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="/Proxy/Login"  role="button">代理登录</a>
				<br>
				<a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="/Index/Pay"  role="button">商户充值</a>
				<a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="/Index/Query"  role="button">用户查码</a>
					<br>
				<a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="//ravey.lanzoui.com/iQ7A2qlpf2j"  role="button">注入器下载</a>
				<a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="//jq.qq.com/?_wv=1027&k=UhOMPfpy"  role="button">加入Q群</a>
            </div>
			
		</div>
		
    </section>
    <section class="wedo py-lg-5 py-5" id="about">
        <div class="container py-lg-5">
            <div class="text-center">
                <h3 class="tittle_head"><?php echo ($name); ?></h3>
                <p class="main_p mt-4 mb-4 pt-2 text-center mx-auto">
支持一键给APK加网络验证/引流弹窗 实现授权收费. <br>
支持微信支付宝直接拉起支付，不须找上家直接充值使用<br>
特点:零门槛 / 响应式 / 清爽 / 极简 / 高效<br>
支持代理代销售模式系统<br>
注入模式:<br>
弹窗网络验证模式<br>
网页版验证模式<br>
加Q群引流摸式<br>
启动图制作模式</p>
            </div>
            <div class="wedo_top text-center py-5">
                <ul>
                    <li><span class="fa fa-cog"></span></li>
                    <li><span class="fa fa-code"></span></li>
                    <li><span class="fa fa-copy"></span></li>
                </ul>
            </div>
        </div>
    </section>
    
</body>


	

 <section class="team-main-sec py-lg-5 py-4" id="team">
        <div class="container">
            <div class="inner-sec-wthree py-lg-5 py-4 speak">
                <div class="text-center">
                    <h3 class="tittle_head">Project development</h3>
                    <p class="main_p mt-4 mb-4 pt-2 text-center mx-auto">This service platform is based on the following sponsors/developers to jointly develop and develop</p>
                </div>
                <div class="row mt-lg-5 mt-4">
                    <div class="col-md-4 team-gd-info text-center">
                        <div class="team-gd">
                            <div class="team-img mb-4">
                                <img src="http://q2.qlogo.cn/headimg_dl?dst_uin=847821199&spec=100" class="img-fluid rounded-circle" alt="user-image">
                            </div>
                            <div class="team-info">
                                <h3 class="mt-md-4 mt-3"><span class="sub-tittle-team">Designer</span> China Ravey </h3>
                                <p>Project chief design developer</p>
                                <ul class="team_social_info mt-md-4 mt-3">
                                    <li class="mb-2 google"><a href="https://jq.qq.com/?_wv=1027&k=5eFlhhB"><i class="fa fa-google mr-1"></i>Google</a></li>
                                    <li class="mb-2 twitter"><a  target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=847821199&site=qq&menu=yes"><i class="fa fa-qq mr-1"></i>Tencent QQ</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 team-gd-info text-center">
                        <div class="team-gd">
                            <div class="team-img mb-4">
                                <img src="http://q2.qlogo.cn/headimg_dl?dst_uin=2441800534&spec=100" class="img-fluid rounded-circle" alt="user-image">
                            </div>
                            <div class="team-info">
                                <h3 class="mt-md-4 mt-3"><span class="sub-tittle-team">Designer</span> China Paper </h3>
                                <p>Project chief design developer</p>
                                <ul class="team_social_info mt-md-4 mt-3">
                                    <li class="mb-2 google"><a href="https://jq.qq.com/?_wv=1027&k=5eFlhhB"><i class="fa fa-google mr-1"></i>Google</a></li>
                                    <li class="mb-2 twitter"><a  target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=2441800534&site=qq&menu=yes"><i class="fa fa-qq mr-1"></i>Tencent QQ</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                   
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>
    <div class="cpy-right text-center pb-5">
            <ul class="social_section_1info mb-lg-4">
                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
            </ul>
            <p class="copy-w3ls mb-4">Copyright © 2019-2025 <?php echo ($name); ?>™ All Rights Reserved.</p>
    </div>
</body>
</html>


</html>