<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zxx">
<head>
    <title><?php echo ($name); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="" />
    <script>
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <link href="/static/css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="/static/css/style.css" type="text/css" rel="stylesheet" media="all">
    <link href="/static/css/font-awesome.min.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800" rel="stylesheet">
</head>

<body>
    <section class="main-banner" id="home">
        
        <div class="container">
            <div class="baner-info-w3ls text-left">
                <h1><?php echo ($name); ?></h1>
                <h6 class="mx-auto mt-4">软件授权管理一站式解决方案，业务上云，拥抱云时代</h6>
                <a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="/Home/Login"  role="button">商户登录</a>
                <a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="/Proxy/Login"  role="button">代理登录</a>
				<br>
				<a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="/Index/Pay"  role="button">商户充值</a>
				<a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr scroll" href="/Index/Query"  role="button">用户查码</a>
            </div>
			<div class="rotate">
                <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($qq); ?>&site=qq&menu=yes"><img border="0" src="http://pub.idqqimg.com/qconn/wpa/button/button_11.gif" alt="点击这里给我发消息" title="点击这里给我发消息"/></a>
                <a target="_blank" href="https://jq.qq.com/?_wv=1027&k=5MVaPK4"><img border="0" src="//pub.idqqimg.com/wpa/images/group.png" alt="爱腾讯☆爱生活" title="爱腾讯☆爱生活"></a>                 
            </div>
		</div>
		
    </section>
    <section class="wedo py-lg-5 py-5" id="about">
        <div class="container py-lg-5">
            <div class="text-center">
                <h3 class="tittle_head"><?php echo ($name); ?></h3>
                <p class="main_p mt-4 mb-4 pt-2 text-center mx-auto">
支持一键给APK加网络验证/引流弹窗 实现授权收费. 
                  ..全新网络验证注入机制 
支持所有加固
支持9.0系统
特点:不修改原始安装包 可套加固上验证
支持市场上所有百分之九十以上的加固直接注入网络验证
支持微信支付宝直接拉起支付，不须找上家直接充值使用
注入模式为
超强过加固模式
弹窗网络验证模式
网页版验证模式
加群引流摸式
启动图制作模式</p>
            </div>
            <div class="wedo_top text-center py-5">
                <ul>
                    <li><span class="fa fa-cog"></span></li>
                    <li><span class="fa fa-code"></span></li>
                    <li><span class="fa fa-copy"></span></li>
                </ul>
            </div>
        </div>
    </section>
    <div class="cpy-right text-center pb-5">
            <ul class="social_section_1info mb-lg-4">
                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
            </ul>
            <p class="copy-w3ls mb-4">Copyright © 2019-2025 <?php echo ($name); ?>™ All Rights Reserved.</p>
    </div>
</body>
</html>