<?php

return array(//'配置项'=>'配置值'

    'VIEW_PATH'=> APP_PATH.'../template/Home/',
);
